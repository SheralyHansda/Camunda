package com.sheraly.workflow.task;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.Expression;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.model.bpmn.instance.ServiceTask;
import org.camunda.bpm.model.bpmn.instance.camunda.CamundaProperties;
import org.camunda.bpm.model.bpmn.instance.camunda.CamundaProperty;
import org.springframework.stereotype.Component;


@Component
public class WelcomeTask implements JavaDelegate{
private Expression variable;
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		
		ServiceTask serviceTask = (ServiceTask)execution.getBpmnModelElementInstance();
		CamundaProperties camundaproperties = serviceTask.getExtensionElements().getElementsQuery().filterByType(CamundaProperties.class).singleResult();
		
		for (CamundaProperty camundaProperty : camundaproperties.getCamundaProperties()) {
				
		System.out.println("name=>"+camundaProperty.getCamundaName());
		System.out.println("value=>"+ camundaProperty.getCamundaValue());
		
	System.out.println("Welcome Camunda");	
	//System.out.println(qaUrl.getValue(execution));
	System.out.println("variable = " + variable.getValue(execution));
		
		}
	}
}
