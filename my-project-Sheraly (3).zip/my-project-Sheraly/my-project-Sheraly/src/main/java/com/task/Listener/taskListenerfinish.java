package com.task.Listener;

import org.camunda.bpm.engine.delegate.DelegateTask;
import org.camunda.bpm.engine.delegate.TaskListener;

public class taskListenerfinish implements TaskListener {

	@Override
	public void notify(DelegateTask delegateTask) {
		System.out.println("Complete Task Listener!!!");

	}

}
